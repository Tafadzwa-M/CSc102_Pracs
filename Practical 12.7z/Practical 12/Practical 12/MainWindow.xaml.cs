﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practical_12
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    ///
    public class Runners
    {
        string name;
        int minutes;
        int seconds;
        int age;
        
        public Runners(string n, int min, int sec, int a)
        {
            name = n;
            minutes = min;
            seconds = sec;
            age = a;
        }
    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Dictionary<string, string> runners = new Dictionary<string, string>();


        private string SetTime()
        {
            string m = (Minutes.Text);
            string s = (Seconds.Text);
            string time = (m + ":" + s);
            return (time);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string names = Name.Text;
            runners.Add(names, SetTime());
           

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            for(int i = 0; i <runners.Count; i++)
            {
                Textbox.Text += runners.Keys.ElementAt(i) + " " + runners.Values.ElementAt(i) + "\r\n";
            }
            
        }
    }
}
